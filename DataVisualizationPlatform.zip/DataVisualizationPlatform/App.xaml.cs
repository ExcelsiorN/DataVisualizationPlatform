﻿using DataVisualizationPlatform.ViewModels;
using System.Windows;

namespace DataVisualizationPlatform
{
    public partial class App : Application
    {
        public static MainViewModel MainVM = new MainViewModel();
    }
}